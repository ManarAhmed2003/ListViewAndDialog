
import 'dart:ui';

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Home(),
  ));
}
class Home extends StatelessWidget {
  final List <String> doList = <String> ['Communication Systems Quiz','OS Report','Buy some stuff','Go to the Gym','Flutter Task','Flutter Task بردو '];
  final List <String> times = <String> ['10:00 AM','11:00 AM','1:00 PM', '2:00 PM','4:00 PM','6:00 PM'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF4368FF),
     appBar: AppBar(
       backgroundColor: Color(0xFF4368FF),
       centerTitle: true,
       title:Text ('Todo List',
         style:TextStyle(
           fontSize: 40,
         fontFamily: 'raleway',
         //  fontWeight: FontWeight.bold,
         ) ,),
     ),

      body: ListView.custom(
          childrenDelegate: SliverChildListDelegate(
            List.generate(6, (index) {
              return Container(
                margin: EdgeInsets.only(bottom: 10),
                child: Center(
                  child: ListTile(
                    title: Text('${doList[index]}',
                      style:TextStyle(
                        fontSize: 25,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ) ,),
                    subtitle: Text('${times[index]}',
                    style: TextStyle(
                      fontSize: 25,
                      color: Colors.white,
                    ),),
                trailing: IconButton(
    icon: Icon(Icons.delete,color: Colors.white,size: 30,),
    onPressed: (){showDialog(
    context: context,
    builder: (BuildContext context){
    return AlertDialog(
    title: Text('Delete',
      style:TextStyle(
        fontSize: 40,
        fontWeight: FontWeight.bold,
        color: Colors.black,
      ) ,),
    content: Text('Are you sure you want to delete this item ?',
      style:TextStyle(
        fontSize: 28,
        color: Colors.grey,
      ) ,),
    actions: [
    RaisedButton(
    child: Text('Cancel',
    style: TextStyle(
      fontSize: 28,
      color: Colors.grey,
    ),
    ),
    onPressed: (){
    Navigator.of(context).pop();
    },
    ),
    RaisedButton(
    child: Text('Yes',
      style: TextStyle(
      fontSize: 28,
      color: Colors.red,
      ),
    ),
    onPressed: (){
    Navigator.of(context).pop();
    },
    ),
    ],
    );
    }
    );
    //    trailing: Icon(Icons.delete,
    //   size: 30,
    //       color:Colors.white ,
    }),
                //    onTap: (){
                   //   showDialog(
    ),
    ),
                      );
                    },
                  ),
                ),
              ),
    );
            }



  }

