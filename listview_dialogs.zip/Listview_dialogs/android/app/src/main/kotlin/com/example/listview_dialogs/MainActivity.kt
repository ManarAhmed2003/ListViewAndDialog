package com.example.listview_dialogs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
